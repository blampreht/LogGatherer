__author__ = 'Luka.Grah'


def add_server(param, param1, param2, db):
    return None